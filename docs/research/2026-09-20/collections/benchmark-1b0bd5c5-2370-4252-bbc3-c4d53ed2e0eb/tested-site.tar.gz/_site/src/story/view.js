export function createStoryView(){const e=document.createElement("dialog");e.id="story-workspace",e.className="story-workspace",e.setAttribute("aria-label","Photo story studio"),e.innerHTML=`
    <header class="story-head">
      <button class="button secondary" id="story-back" type="button">Back</button>
      <strong id="story-name">Photo stories</strong>
      <button class="button secondary story-history" id="story-undo" type="button" aria-label="Undo story edit" disabled>\u21B6</button>
      <button class="button secondary story-history" id="story-redo" type="button" aria-label="Redo story edit" disabled>\u21B7</button>
      <button class="button primary" id="story-export" type="button" disabled>Export</button>
    </header>
    <section id="story-intro" class="story-intro">
      <div class="story-intro-copy"><p class="eyebrow">Made from your moments</p><h1>Your photos.<br>One story.</h1>
        <p>Turn 6\u201312 photos into a set worth swiping through. Change the look, frame every photo, and make the words yours.</p>
        <label class="story-field">Story title<input id="story-title" maxlength="80" value="My story" autocomplete="off"></label>
        <button class="button primary" id="story-choose" type="button">Choose 6\u201312 photos</button>
        <p class="story-note">Private editing on this device. PNG, JPEG and WebP photos.</p>
      </div>
      <section class="story-library" aria-label="Saved stories"><h2>Continue a story</h2><div id="story-library"></div></section>
    </section>
    <section id="story-body" class="story-body" hidden>
      <div class="story-stage"><img id="story-preview" alt="Story preview" hidden><div id="story-preview-message" role="status">Preparing your story\u2026</div></div>
      <nav id="story-filmstrip" class="story-filmstrip" aria-label="Story slides"></nav>
      <nav class="story-dock" aria-label="Story tools">
        <button type="button" data-story-tool="look">Look</button><button type="button" data-story-tool="layout">Layout</button>
        <button type="button" data-story-tool="photos">Photos</button><button type="button" data-story-tool="text">Text</button>
        <button type="button" data-story-tool="adjust">Adjust</button><button type="button" data-story-tool="cutout">Cutout</button>
      </nav>
    </section>
    <footer class="story-status"><span id="story-status" role="status"></span><button id="story-retry-save" class="button secondary" type="button" hidden>Retry save</button><button id="story-save-copy" class="button secondary" type="button" hidden>Save a copy</button></footer>
    <input id="story-files" type="file" accept="image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp" multiple hidden>
  `;const o=document.createElement("dialog");return o.id="story-sheet",o.className="story-sheet",o.setAttribute("aria-labelledby","story-sheet-title"),o.innerHTML=`<header><h2 id="story-sheet-title"></h2><button class="button secondary" id="story-sheet-cancel" type="button">Cancel</button></header>
    <div id="story-sheet-content" class="story-sheet-content"></div><footer>
      <p id="story-sheet-preview-status" class="story-note" role="status" hidden></p>
      <button id="story-retry-preview" class="button secondary" type="button" hidden>Retry preview</button>
      <button id="story-sheet-apply" class="button primary" type="button">Apply</button></footer>`,document.body.append(e,o),{root:e,sheet:o,get:t=>document.getElementById(`story-${t}`)}}export function field(e,o){const n=document.createElement("label");n.className="story-field";const t=document.createElement("span");return t.textContent=e,n.append(t,o),n}export function select(e,o,n){const t=document.createElement("select");t.setAttribute("aria-label",n);for(const[r,a]of e){const s=document.createElement("option");s.value=r,s.textContent=a,t.append(s)}return t.value=o,t}export function action(e,o,n=!1){const t=document.createElement("button");return t.type="button",t.className=`button ${n?"primary":"secondary"}`,t.textContent=e,t.addEventListener("click",o),t}export function range(e,o,n,t,r,a){const s=document.createElement("input");s.type="range",Object.assign(s,{min:n,max:t,step:r,value:o}),s.setAttribute("aria-label",e);const i=document.createElement("output");i.value=String(o);const u=field(e,s);return u.append(i),s.addEventListener("input",()=>{i.value=s.value,a(Number(s.value))}),u}
