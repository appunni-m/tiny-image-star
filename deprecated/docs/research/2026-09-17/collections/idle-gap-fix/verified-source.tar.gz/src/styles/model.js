import { assertEngineCompatibility, canonicalJSON, clone, createSceneProject, ENGINE_IDENTITY, newId, resolveSlide, validateData, validateProject } from "../project/model.js";
import { applyProjectCommand } from "../project/history.js";
import { adaptStoryLayoutCommand, hasAdaptiveLayout, validateStoryLayout } from "../story/layout.js";
import { STORY_LOOKS } from "../story/recipes.js";
import { validateCutoutEffects } from "../compositor/cutout-effects-spec.js";

export const MAX_STYLE_BYTES = 32 * 1024;
export const STYLE_CAPABILITIES = Object.freeze(["scene-v1", "photo-look-v1", "builtin-text-v1", "photo-prints-v1", "cutout-effects-v1", "png-output", "jpeg-output"]);
const layoutKeys = ["id", "version", "margin", "gap", "border", "header", "captionMin", "captionMax"];
const plain = (value) => value && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
const bounded = (value, min, max) => Number.isFinite(value) && value >= min && value <= max;
const color = (value) => typeof value === "string" && /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(value);
function check(condition, message = "This style contains unsupported or invalid settings.") { if (!condition) throw new Error(message); }
function keys(value, allowed) { check(plain(value) && Object.keys(value).every((key) => allowed.includes(key))); }
const requiredFor = (components) => ["scene-v1", ...(components.look ? ["photo-look-v1"] : []), ...(components.text ? ["builtin-text-v1"] : []),
  ...(components.layout ? ["photo-prints-v1"] : []), ...(components.cutoutEffects ? ["cutout-effects-v1"] : []), ...(components.output ? [`${components.output.format}-output`] : [])];
export const styleKey = (style) => `${style.id}@${style.revision}`;
export const styleHasStrength = (style) => Object.entries(style.components.look?.appearance ?? {}).some(([key, value]) => value !== (key === "grayscaleMix" ? 0 : 1));

function envelope(id, name, description, components) {
  const style = { kind: "tiny-image-star/style", version: 1, id, revision: 1, name, description,
    engine: { name: ENGINE_IDENTITY.name, versions: [ENGINE_IDENTITY.version], compositors: [ENGINE_IDENTITY.compositor] },
    requires: requiredFor(components), supported: { photoCounts: { min: 6, max: 12 }, variants: ["portrait", "tall"] },
    seed: { mode: "project" }, assets: [], components, controls: [] };
  if (styleHasStrength(style)) style.controls.push("appearance-strength");
  return validateStyle(style);
}

export function validateStyle(style) {
  validateData(style);
  check(new TextEncoder().encode(JSON.stringify(style)).length <= MAX_STYLE_BYTES, "Style files must be 32 KiB or smaller.");
  check(style?.kind === "tiny-image-star/style" && style.version === 1, "This style file needs a different app version. The file has not been changed.");
  keys(style, ["kind", "version", "id", "revision", "name", "description", "engine", "requires", "supported", "seed", "assets", "components", "controls"]);
  check(typeof style.id === "string" && /^[a-zA-Z0-9][a-zA-Z0-9:._-]{0,127}$/.test(style.id) && !["constructor", "prototype"].includes(style.id));
  check(Number.isSafeInteger(style.revision) && bounded(style.revision, 1, 1_000_000));
  check(typeof style.name === "string" && style.name.trim().length > 0 && style.name.length <= 80, "Give the style a name of 1–80 characters.");
  check(typeof style.description === "string" && style.description.length <= 240);
  keys(style.engine, ["name", "versions", "compositors"]);
  check(typeof style.engine.name === "string" && /^[a-z0-9-]{1,64}$/.test(style.engine.name));
  for (const key of ["versions", "compositors"]) check(Array.isArray(style.engine[key]) && style.engine[key].length > 0 && style.engine[key].length <= 8
    && style.engine[key].every((item) => typeof item === "string" && /^[a-zA-Z0-9.+_-]{1,80}$/.test(item)));
  check(Array.isArray(style.requires) && style.requires.length <= 16 && new Set(style.requires).size === style.requires.length
    && style.requires.every((entry) => typeof entry === "string" && /^[a-z0-9-]{1,64}$/.test(entry)));
  keys(style.supported, ["photoCounts", "variants"]); keys(style.supported.photoCounts, ["min", "max"]);
  check(Number.isInteger(style.supported.photoCounts.min) && Number.isInteger(style.supported.photoCounts.max)
    && bounded(style.supported.photoCounts.min, 6, 12) && bounded(style.supported.photoCounts.max, style.supported.photoCounts.min, 12));
  check(Array.isArray(style.supported.variants) && style.supported.variants.length > 0 && style.supported.variants.length <= 2
    && new Set(style.supported.variants).size === style.supported.variants.length && style.supported.variants.every((id) => ["portrait", "tall"].includes(id)));
  keys(style.seed, ["mode"]); check(style.seed.mode === "project");
  check(Array.isArray(style.assets) && style.assets.length === 0, "This style version supports built-in fonts and parameters. Asset packs need a separately supported format.");
  keys(style.components, ["look", "text", "layout", "output", "cutoutEffects"]); check(Object.keys(style.components).length > 0, "Choose at least one setting to save.");
  const { look, text, layout, output } = style.components;
  const validation = createSceneProject({ nodes: { caption: { id: "caption", kind: "text", space: "slide", frame: { x: .1, y: .1, width: .8, height: .2 }, text: "" } } });
  if (look !== undefined) {
    keys(look, ["appearance", "paper", "ink", "accent"]); check([look.paper, look.ink, look.accent].every(color));
    validation.shared.appearance = look.appearance;
  }
  if (text !== undefined) {
    keys(text, ["caption", "number"]); check(text.caption && text.number);
    for (const value of [text.caption, text.number]) {
      keys(value, ["style", "color"]); check(color(value.color));
      validation.nodes.caption.style = value.style; validateProject(validation);
    }
  }
  if (layout !== undefined) {
    keys(layout, [...layoutKeys, "arrangement", "tilt"]);
    check(["auto", "row", "stack"].includes(layout.arrangement) && [-3, 0, 3].includes(layout.tilt));
    validateStoryLayout({ recipe: { layout: { ...Object.fromEntries(layoutKeys.map((key) => [key, layout[key]])), slides: {} } }, slides: [], nodes: {} });
  }
  if (output !== undefined) {
    keys(output, ["variant", "format"]); check(["portrait", "tall"].includes(output.variant) && ["png", "jpeg"].includes(output.format));
  }
  if (style.components.cutoutEffects !== undefined) validateCutoutEffects(style.components.cutoutEffects);
  check(requiredFor(style.components).every((requirement) => style.requires.includes(requirement)), "This style omits a required capability declaration.");
  check(Array.isArray(style.controls) && canonicalJSON(style.controls) === canonicalJSON(styleHasStrength(style) ? ["appearance-strength"] : []));
  validateProject(validation);
  return style;
}

export function styleFromLook(look) {
  const known = STORY_LOOKS.find((entry) => entry.id === look.id && entry.revision === look.revision);
  const style = envelope(`builtin:${look.id}`, look.name, look.description ?? known?.description ?? "Saved photo treatment.", {
    look: { appearance: clone(look.appearance), paper: look.paper, ink: look.ink, accent: look.accent },
  });
  style.revision = look.revision; return validateStyle(style);
}
export const curatedStyles = () => STORY_LOOKS.map(styleFromLook);

export function styleCompatibility(style, project, variantId) {
  validateStyle(style);
  if (style.engine.name !== ENGINE_IDENTITY.name || !style.engine.versions.includes(ENGINE_IDENTITY.version)
    || !style.engine.compositors.includes(ENGINE_IDENTITY.compositor)) return "This style needs a different renderer version. Choose a built-in look instead.";
  const missing = style.requires.filter((entry) => !STYLE_CAPABILITIES.includes(entry));
  if (missing.length) return `Unavailable requirement: ${missing.join(", ")}. Choose a built-in look instead.`;
  if (project) {
    try { assertEngineCompatibility(project); } catch (error) { return error.message; }
    const count = new Set(project.slides.flatMap((slide) => slide.nodeIds.filter((id) => project.nodes[id].kind === "image" && !project.nodes[id].connection))).size;
    if (count < style.supported.photoCounts.min || count > style.supported.photoCounts.max) return `This style needs ${style.supported.photoCounts.min}–${style.supported.photoCounts.max} photos.`;
    const shape = style.components.output?.variant ?? variantId ?? project.recipe.outputVariant;
    if (!style.supported.variants.includes(shape) || !project.variants.some((variant) => variant.id === shape)) return "This style does not support the selected output shape.";
    if (style.components.cutoutEffects && !Object.values(project.nodes).some((node) => node.kind === "image" && node.maskId)) return "Choose a subject in Cutout before applying this finish.";
  }
  return "";
}

export function captureStoryStyle(project, slideId, name, inclusion = { look: true, text: true }) {
  const resolved = resolveSlide(project, slideId, project.recipe.outputVariant), nodes = resolved.nodes;
  const photo = nodes.find((node) => node.kind === "image"), caption = nodes.find((node) => node.id.endsWith(":caption"));
  const number = nodes.find((node) => node.id.endsWith(":number")), paper = nodes.find((node) => node.id.endsWith(":paper"));
  check(photo && caption && number && paper, "This slide does not have reusable photo-story settings.");
  const components = {};
  if (inclusion.look) components.look = { appearance: clone(photo.appearance), paper: paper.color, ink: caption.color, accent: number.color };
  if (inclusion.text) {
    check(!caption.fontId && !number.fontId, "Custom fonts need a licensed asset pack. Save the other settings without Text style.");
    components.text = Object.fromEntries([["caption", caption], ["number", number]].map(([key, node]) => [key, { style: clone(node.style ?? {}), color: node.color }]));
  }
  if (inclusion.layout) {
    const layout = validateStoryLayout(project), binding = layout.slides[slideId]; check(binding, "Adapt this slide to photos before saving its layout.");
    check([-3, 0, 3].includes(photo.rotation ?? 0), "This rotation is not part of a reusable photo-print layout.");
    components.layout = { ...Object.fromEntries(layoutKeys.map((key) => [key, binding.constraints?.[key] ?? layout[key]])), arrangement: binding.arrangement, tilt: photo.rotation ?? 0 };
  }
  if (inclusion.output) components.output = { variant: project.recipe.outputVariant, format: project.recipe.outputFormat ?? "jpeg" };
  if (inclusion.cutoutEffects) {
    const subject = nodes.find((node) => node.id === inclusion.effectPhotoId);
    check(subject?.kind === "image" && subject.cutoutEffects, "Choose a photo with an outline or shadow to save its finish.");
    components.cutoutEffects = clone(subject.cutoutEffects);
  }
  return envelope(newId("style"), name.trim(), "Your reusable story settings.", components);
}

export function storyStyleCommand(project, style, { strength = 1, slideId = null, keepPositions = true } = {}) {
  validateProject(project); const problem = styleCompatibility(style, project);
  check(!problem, problem); check(bounded(strength, 0, 1), "Choose a style strength from 0–100%.");
  const selected = project.slides.filter((slide) => !slideId || slide.id === slideId); check(selected.length, "Choose a slide for this style.");
  if (style.components.cutoutEffects) check(selected.some((slide) => slide.nodeIds.some((id) => project.nodes[id].kind === "image" && project.nodes[id].maskId)), "Choose a subject in Cutout on a selected slide before applying this finish.");
  let next = clone(project); const { look, text, layout, output } = style.components;
  if (look && !slideId) next.shared.appearance = Object.fromEntries(Object.entries(look.appearance).map(([key, value]) => [key, (key === "grayscaleMix" ? 0 : 1) + (value - (key === "grayscaleMix" ? 0 : 1)) * strength]));
  for (const slide of selected) {
    for (const id of slide.nodeIds) {
      const node = next.nodes[id];
      if (node.kind === "image" && node.maskId && style.components.cutoutEffects) node.cutoutEffects = clone(style.components.cutoutEffects);
      if (look) {
        if (node.kind === "image" && slideId) node.appearanceBase = Object.fromEntries(Object.entries(look.appearance).map(([key, value]) => [key, (key === "grayscaleMix" ? 0 : 1) + (value - (key === "grayscaleMix" ? 0 : 1)) * strength]));
        if (id.endsWith(":paper")) node.color = look.paper;
        if (id.endsWith(":caption")) node.color = look.ink;
        if (id.endsWith(":number")) node.color = look.accent;
      }
      const typography = text && (id.endsWith(":caption") ? text.caption : id.endsWith(":number") ? text.number : null);
      if (typography) { node.style = clone(typography.style); node.color = typography.color; delete node.fontId; }
    }
    if (layout) {
      // Adopt or validate this slide, then replace only reusable constraints.
      next = applyProjectCommand(next, adaptStoryLayoutCommand(next, slide.id)).project;
      next.recipe.layout.slides[slide.id].constraints = Object.fromEntries(layoutKeys.filter((key) => !["id", "version"].includes(key)).map((key) => [key, layout[key]]));
      const pairs = next.recipe.layout.slides[slide.id].photos;
      pairs.forEach((pair, index) => { for (const id of [pair.imageId, pair.borderId]) next.nodes[id].rotation = index % 2 ? -layout.tilt : layout.tilt; });
      next = applyProjectCommand(next, adaptStoryLayoutCommand(next, slide.id, { arrangement: layout.arrangement, resetPositions: !keepPositions })).project;
    } else if (text && hasAdaptiveLayout(next, slide.id)) next = applyProjectCommand(next, adaptStoryLayoutCommand(next, slide.id)).project;
  }
  if (output) { next.recipe.outputVariant = output.variant; next.recipe.outputFormat = output.format; }
  const applied = { definition: clone(style), strength };
  if (slideId) next.recipe.slideStyles = { ...next.recipe.slideStyles, [slideId]: applied };
  else next.recipe.style = applied;
  validateProject(next);
  const commands = [];
  for (const [id, node] of Object.entries(next.nodes)) if (canonicalJSON(node) !== canonicalJSON(project.nodes[id])) commands.push({ type: "node", id, value: node });
  for (const type of ["shared", "slides", "recipe"]) if (canonicalJSON(next[type]) !== canonicalJSON(project[type])) commands.push({ type, value: next[type] });
  return { type: "group", commands };
}

export function serializeStyle(style) { validateStyle(style); return `${JSON.stringify(style, null, 2)}\n`; }
export function parseStyle(text) {
  check(typeof text === "string" && new TextEncoder().encode(text).length <= MAX_STYLE_BYTES, "Style files must be 32 KiB or smaller.");
  let value; try { value = JSON.parse(text); } catch { throw new Error("This file is not valid style JSON."); }
  return clone(validateStyle(value));
}
