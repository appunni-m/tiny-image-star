import { createPillowEngine, describeError } from "../engine/pillow.js";
import { isAnimatedImage } from "../input.js";
import { outputRelativePath, sourceRelativeParts, settingsForLargeJob, validateSourceMetadata } from "./core.js";
import { MAX_SOURCE_BYTES } from "../processing/policy.js";
import { digestBytes, saveJournaledOutput } from "./output.js";

let enginePromise;
let loadedEngine;

function loadEngine() {
  if (!enginePromise) enginePromise = createPillowEngine().then((engine) => { loadedEngine = engine; return engine; });
  return enginePromise;
}

async function resolveFile(root, relativePath) {
  const parts = sourceRelativeParts(relativePath);
  const name = parts.pop();
  let directory = root;
  for (const part of parts) directory = await directory.getDirectoryHandle(part);
  return directory.getFileHandle(name);
}

async function processEntry(message) {
  const started = message.diagnostics === true ? performance.now() : 0;
  const engine = await loadEngine();
  const readStarted = message.diagnostics === true ? performance.now() : 0;
  const sourceHandle = await resolveFile(message.sourceRoot, message.entry.relativePath);
  const source = await sourceHandle.getFile();
  validateSourceMetadata(message.entry, source);
  if (source.size > MAX_SOURCE_BYTES || source.size !== message.expectedSource?.size || source.lastModified !== message.expectedSource?.lastModified) throw new Error("The source changed or is too large. Retry it after the source has finished saving.");
  const sourceBuffer = await source.arrayBuffer();
  const sourceBytes = new Uint8Array(sourceBuffer);
  const readFinished = message.diagnostics === true ? performance.now() : 0;
  if (isAnimatedImage(sourceBytes)) throw new Error("Animated images are not supported yet.");
  const settings = settingsForLargeJob(message.recipe);
  if (message.type === "inspect") {
    const metadata = engine.inspect({ bytes: sourceBuffer });
    self.postMessage({ type: "inspect-result", jobId: message.jobId, index: message.entry.index, ...metadata, heapBytes: engine.heapBytes() });
    return;
  }
  if (!message.memoryEstimate) throw new Error("Missing processing memory budget");
  const sourceDigest = await digestBytes(sourceBuffer);
  const renderStarted = message.diagnostics === true ? performance.now() : 0;
  const result = await engine.render({
    id: `${message.jobId}:${message.entry.index}`,
    name: message.entry.sourceName,
    bytes: sourceBuffer,
    memoryEstimate: message.memoryEstimate,
    diagnostics: message.diagnostics === true,
  }, settings);
  const saveStarted = message.diagnostics === true ? performance.now() : 0;
  const relativeOutput = outputRelativePath(message.entry.relativePath, message.recipe.name, result.format);
  const committed = await saveJournaledOutput({ jobId: message.jobId, entry: message.entry, owner: message.owner,
    outputRoot: message.outputRoot, outputPath: relativeOutput, result, sourceDigest });
  self.postMessage({
    type: "result",
    workerId: message.workerId,
    jobId: message.jobId,
    index: message.entry.index,
    claimId: message.entry.claimId,
    recovered: committed.recovered,
    outputPath: relativeOutput,
    sourceBytes: source.size,
    outputBytes: result.outputBytes,
    width: result.width,
    height: result.height,
    format: result.format,
    heapBytes: engine.heapBytes(),
    ...(message.diagnostics === true ? { diagnostics: {
      schema: "tinystar/folder-timings@1", engineWaitMs: readStarted - started,
      sourceReadMs: readFinished - readStarted, sourceDigestMs: renderStarted - readFinished,
      renderMs: saveStarted - renderStarted, journalSaveMs: performance.now() - saveStarted,
      render: result.diagnostics,
    } } : {}),
  });
}

self.addEventListener("message", (event) => {
  const message = event.data;
  if (!["process", "inspect"].includes(message?.type)) return;
  processEntry(message).catch((error) => {
    self.postMessage({
      type: "error",
      workerId: message.workerId,
      jobId: message.jobId,
      index: message.entry?.index,
      claimId: message.entry?.claimId,
      message: error?.userMessage ?? describeError(error),
      heapBytes: loadedEngine?.heapBytes() ?? 0,
    });
  });
});

self.postMessage({ type: "starting" });
loadEngine()
  .then((engine) => self.postMessage({ type: "ready", capabilities: engine.capabilities, heapBytes: engine.heapBytes() }))
  .catch((error) => self.postMessage({ type: "fatal", message: describeError(error) }));
