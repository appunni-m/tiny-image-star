const DB_NAME = "tiny-image-star.large-jobs";
const DB_VERSION = 1;
const JOB_STORE = "jobs";
const ENTRY_STORE = "entries";
let databasePromise;

function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Local job storage failed."));
  });
}

function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = resolve;
    transaction.onabort = () => reject(transaction.error ?? new Error("Local job storage was interrupted."));
    transaction.onerror = () => reject(transaction.error ?? new Error("Local job storage failed."));
  });
}

export function largeJobStorageAvailable() {
  return typeof globalThis.indexedDB !== "undefined" && typeof globalThis.IDBKeyRange !== "undefined";
}

export function openLargeJobDatabase() {
  if (!largeJobStorageAvailable()) return Promise.reject(new Error("Local job recovery is unavailable in this browser."));
  if (!databasePromise) {
    databasePromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(JOB_STORE)) database.createObjectStore(JOB_STORE, { keyPath: "id" });
        if (!database.objectStoreNames.contains(ENTRY_STORE)) {
          const entries = database.createObjectStore(ENTRY_STORE, { keyPath: ["jobId", "index"] });
          entries.createIndex("by_job_status", ["jobId", "status"], { unique: false });
        }
      };
      request.onsuccess = () => {
        request.result.onversionchange = () => { request.result.close(); databasePromise = undefined; };
        resolve(request.result);
      };
      request.onerror = () => { databasePromise = undefined; reject(request.error); };
    });
  }
  return databasePromise;
}

// Every mutation reads fresh state in one transaction. Strict durability asks
// the browser to persist the journal before an external file is written.
async function transact(mode, callback) {
  const database = await openLargeJobDatabase();
  const transaction = database.transaction([JOB_STORE, ENTRY_STORE], mode, mode === "readwrite" ? { durability: "strict" } : {});
  const done = transactionDone(transaction);
  const jobs = transaction.objectStore(JOB_STORE), entries = transaction.objectStore(ENTRY_STORE);
  try {
    const value = await callback({ jobs, entries });
    await done;
    return value;
  } catch (error) {
    try { transaction.abort(); } catch { /* Already completed or aborted. */ }
    await done.catch(() => {});
    throw error;
  }
}

function checkOwner(job, owner) {
  if (!job) throw new Error("The saved folder job is incomplete.");
  if (!owner || owner.token !== job.owner?.token || owner.epoch !== job.owner?.epoch) {
    throw new Error("This folder job belongs to another tab. Reopen it to continue.");
  }
}

function touch(job, patch = {}) {
  return { ...job, ...patch, revision: Number(job.revision ?? 0) + 1, updatedAt: Date.now() };
}

async function mutate(jobId, owner, callback) {
  return transact("readwrite", async (stores) => {
    const job = await requestResult(stores.jobs.get(jobId));
    checkOwner(job, owner);
    return callback(stores, job);
  });
}

// Creation is insert-only; a stale tab cannot replace an existing job record.
export function putLargeJob(job) {
  return transact("readwrite", async ({ jobs }) => {
    await requestResult(jobs.add({ ...job, owner: null, revision: 0 }));
    return job;
  });
}

// Called only while ownership.js holds the owner lock AND exclusive write gate.
export function beginJobOwnership(jobId, token) {
  return transact("readwrite", async ({ jobs }) => {
    const job = await requestResult(jobs.get(jobId));
    if (!job) throw new Error("The saved folder job no longer exists.");
    const owner = { token, epoch: Number(job.owner?.epoch ?? 0) + 1 };
    const next = touch(job, { owner });
    jobs.put(next);
    return { owner, job: next };
  });
}

export function patchLargeJob(jobId, patch, owner) {
  return mutate(jobId, owner, ({ jobs }, job) => {
    // Counters are maintained by entry transitions; discovery may reset them
    // only after its manifest has been cleared under the same owner.
    const { id, owner: ignoredOwner, revision, ...values } = patch;
    const next = touch(job, values);
    jobs.put(next);
    return next;
  });
}

export function getLargeJob(jobId) {
  return transact("readonly", async ({ jobs }) => await requestResult(jobs.get(jobId)) ?? null);
}

export function listLargeJobs() {
  return transact("readonly", async ({ jobs }) => (await requestResult(jobs.getAll())).sort((a, b) => b.updatedAt - a.updatedAt));
}

export function putManifestEntries(values, owner) {
  if (!values.length) return Promise.resolve();
  return mutate(values[0].jobId, owner, ({ entries }, job) => {
    for (const entry of values) {
      if (entry.jobId !== job.id) throw new Error("Manifest entries must belong to one job.");
      entries.add(entry);
    }
  });
}

export function getManifestPage(jobId, start, count) {
  if (count <= 0) return Promise.resolve([]);
  return transact("readonly", ({ entries }) => requestResult(entries.getAll(IDBKeyRange.bound([jobId, Math.max(0, start)], [jobId, Math.max(0, start + count - 1)]))));
}

function visitStatus(entries, jobId, status, callback) {
  return new Promise((resolve, reject) => {
    const request = entries.index("by_job_status").openCursor(IDBKeyRange.only([jobId, status]));
    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor || callback(cursor) === false) { resolve(); return; }
      cursor.continue();
    };
  });
}

export function claimPendingEntries(jobId, count, owner) {
  if (count <= 0) return Promise.resolve([]);
  return mutate(jobId, owner, async ({ entries }, job) => {
    if (job.status !== "running") return [];
    const claimed = [];
    await visitStatus(entries, jobId, "pending", (cursor) => {
      if (claimed.length >= count) return false;
      const entry = { ...cursor.value, status: "processing", attempts: Number(cursor.value.attempts ?? 0) + 1,
        claimId: crypto.randomUUID(), ownerEpoch: owner.epoch, error: null };
      cursor.update(entry);
      claimed.push(entry);
    });
    return claimed;
  });
}

function checkClaim(entry, claimId, owner) {
  if (!entry || entry.claimId !== claimId || entry.ownerEpoch !== owner.epoch) throw new Error("This image attempt is no longer current.");
}

export function getClaimedEntry(jobId, index, claimId, owner) {
  return transact("readonly", async ({ entries, jobs }) => {
    checkOwner(await requestResult(jobs.get(jobId)), owner);
    const entry = await requestResult(entries.get([jobId, index]));
    checkClaim(entry, claimId, owner);
    return entry;
  });
}

export function releaseClaimedEntries(jobId, claimed, owner) {
  return mutate(jobId, owner, async ({ entries }) => {
    for (const item of claimed) {
      const current = await requestResult(entries.get([jobId, item.index]));
      if (current?.status === "processing" && current.claimId === item.claimId && current.ownerEpoch === owner.epoch) {
        entries.put({ ...current, status: "pending", claimId: null, error: null });
      }
    }
  });
}

export function putOutputIntent(jobId, index, claimId, intent, owner) {
  return mutate(jobId, owner, async ({ entries }) => {
    const entry = await requestResult(entries.get([jobId, index]));
    checkClaim(entry, claimId, owner);
    if (entry.status !== "processing") throw new Error("This image is no longer processing.");
    entries.put({ ...entry, outputIntent: intent });
  });
}

// Completion is idempotent for one claim, including an error arriving after a
// durable success. Counts derive from status transitions, never caller deltas.
export function commitManifestEntry(jobId, index, claimId, patch, owner) {
  return mutate(jobId, owner, async ({ entries, jobs }, job) => {
    const entry = await requestResult(entries.get([jobId, index]));
    checkClaim(entry, claimId, owner);
    if (entry.status === "completed" || entry.status === "failed") return { entry, job };
    if (entry.status !== "processing" || !["completed", "failed"].includes(patch.status)) throw new Error("Invalid image completion.");
    if (patch.status === "completed" && (!entry.outputIntent || patch.outputDigest !== entry.outputIntent.digest)) throw new Error("Missing saved-output journal.");
    const nextEntry = { ...entry, ...patch };
    const nextJob = touch(job, {
      completed: Number(job.completed ?? 0) + Number(patch.status === "completed"),
      failed: Number(job.failed ?? 0) + Number(patch.status === "failed"),
      outputBytes: Number(job.outputBytes ?? 0) + (patch.status === "completed" ? Number(patch.outputBytes) : 0),
    });
    entries.put(nextEntry);
    jobs.put(nextJob);
    return { entry: nextEntry, job: nextJob };
  });
}

function resetStatus(jobId, fromStatus, owner) {
  return mutate(jobId, owner, async ({ entries, jobs }, job) => {
    let changed = 0;
    await visitStatus(entries, jobId, fromStatus, (cursor) => {
      cursor.update({ ...cursor.value, status: "pending", claimId: null, error: null,
        allowSourceChange: fromStatus === "failed" || Boolean(cursor.value.allowSourceChange) });
      changed += 1;
    });
    const next = touch(job, fromStatus === "failed" ? { failed: Math.max(0, Number(job.failed ?? 0) - changed) } : {});
    jobs.put(next);
    return next;
  });
}

export function resetInterruptedEntries(jobId, owner) { return resetStatus(jobId, "processing", owner); }
export function retryFailedEntries(jobId, owner) { return resetStatus(jobId, "failed", owner); }

export function clearManifestEntries(jobId, owner) {
  return mutate(jobId, owner, ({ entries }) => {
    entries.delete(IDBKeyRange.bound([jobId, 0], [jobId, Number.MAX_SAFE_INTEGER]));
  });
}

export function deleteLargeJob(jobId, owner) {
  return mutate(jobId, owner, ({ entries, jobs }) => {
    jobs.delete(jobId);
    entries.delete(IDBKeyRange.bound([jobId, 0], [jobId, Number.MAX_SAFE_INTEGER]));
  });
}
