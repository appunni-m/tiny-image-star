import { getProcessingScheduler } from "../processing/client.js";
import { inspectionWork } from "../processing/policy.js";
import { exifOrientationFromBytes } from "../engine/pillow.js";
import { inputProblem } from "../input.js";
import { hashAsset } from "../project/storage.js";
import { newId } from "../project/model.js";

export const STORY_SOURCE_LIMIT = 96 * 1024 * 1024;

export async function importStoryPhotos(files, { signal, onProgress = () => {}, pool = getProcessingScheduler() } = {}) {
  if (!files.length || files.length > 12 || files.reduce((sum, file) => sum + file.size, 0) > STORY_SOURCE_LIMIT) throw new Error("Choose up to 12 photos totaling at most 96 MB.");
  const controller = new AbortController(), abort = () => controller.abort();
  signal?.addEventListener("abort", abort, { once: true }); if (signal?.aborted) abort();
  let completed = 0;
  try {
    return await Promise.all(files.map(async (file) => {
      let sha256, orientation;
      const task = pool.enqueue({ kind: "image", priority: 0, signal: controller.signal, estimate: inspectionWork(file.size), workClass: "story-import",
        prepare: async () => {
          const bytes = await file.arrayBuffer();
          if (controller.signal.aborted) throw new DOMException("Import cancelled.", "AbortError");
          const head = new Uint8Array(bytes, 0, Math.min(bytes.byteLength, 12));
          const png = [137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => head[index] === value);
          const jpeg = head[0] === 255 && head[1] === 216 && head[2] === 255;
          const webp = String.fromCharCode(...head.slice(0, 4)) === "RIFF" && String.fromCharCode(...head.slice(8, 12)) === "WEBP";
          if (!png && !jpeg && !webp) throw new Error(`${file.name}: Choose a PNG, JPEG or WebP photo.`);
          const problem = inputProblem(bytes); if (problem) throw new Error(`${file.name}: ${problem.message}`);
          sha256 = await hashAsset(bytes); orientation = Number(exifOrientationFromBytes(new Uint8Array(bytes)) ?? 1);
          return { message: { type: "inspect", file: { bytes } }, transfer: [bytes] };
        },
      });
      const result = await task.promise;
      if (result.type !== "inspect-result") throw new Error(`${file.name}: ${result.message ?? "This photo could not be read."}`);
      onProgress(++completed, files.length);
      const swap = orientation >= 5 && orientation <= 8;
      return { source: file, asset: { id: newId("asset"), kind: "image", name: file.name, type: file.type || "application/octet-stream", byteLength: file.size,
        sha256, width: swap ? result.height : result.width, height: swap ? result.width : result.height, orientation: "exif-to-upright", lastModified: file.lastModified || 0 } };
    }));
  } catch (error) { controller.abort(); throw error; }
  finally { signal?.removeEventListener("abort", abort); }
}
