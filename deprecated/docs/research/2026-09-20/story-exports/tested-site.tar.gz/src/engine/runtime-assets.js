export const USE_BROTLI_WASM=!0;
